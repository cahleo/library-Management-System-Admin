import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ReturnedBooksData {
 
    JTable returnBook;

    String[] headers = {"BOOK ID", "STUDENT ID", "NAME", "RETURNED DATA"};
    Object[][] returnedbooks = {
        {"TECH005", "21010", "Victoria Kingsley", "2025-10-16"},
        {"LIFE005", "21011", "Luna Sarton","2025-10-18"},
        {"MONEY004", "21012", "Corrine Stanford", "2025-10-15"},
        {"MONEY005", "21013", "Shia Sheridan", "2025-10-1"},
        {"LIFE003","21014", "Cain Apollo", "2025-10-13"},
        {"TECH002","21015", "Gin Grey", "2025-10-13"},
        {"MONEY003","21016", "Ethan Huges", "2025-10-2"},
        {"MONEY002","21017", "Priam Grey", "2025-10-19"},
        {"MONEY005","21018", "Lucas Tyler", "2025-10-5"},
        {"TECH001","21019", "Luke Tyler","2025-10-11"}
    };

    DefaultTableModel model = new DefaultTableModel(headers, 0);

    public void setTable(JTable returnTable) {
        this.returnBook = returnTable;
    }

    public void getreturnBook() {
        model.setRowCount(0); 
        for (Object[] book : returnedbooks) {
            model.addRow(book);
        }
        returnBook.setModel(model); 
    }
     public void deleteStudent(int rowID) {
    if (model != null && rowID >= 0 && rowID < model.getRowCount()) {
        model.removeRow(rowID);  // removes the row from the JTable
        System.out.println("Deleted row: " + rowID);
    } else {
        System.out.println("Invalid row index: " + rowID);
    }
}

}

    
