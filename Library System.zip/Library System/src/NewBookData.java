import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class NewBookData {

    private JTable scienceTable;
    private JTable technologyTable;
    private JTable lifeTable;
    private JTable moneyTable;

    String[] headers = {"Book ID", "Book Name", "Publisher", "Published Year", "Status"};

    private final Object[][] scienceBooks = {
        {"SCI001", "A Brief History of Time", "Bantam Books", 1988, "AVAILABLE"},
        {"SCI002", "The Selfish Gene", "Oxford University Press", 1976, "AVAILABLE"},
        {"SCI003", "The Elegant Universe", "W. W. Norton & Company", 1999, "AVAILABLE"},
        {"SCI004", "Cosmos", "Random House", 1980, "AVAILABLE"},
        {"SCI005", "The Origin of Species", "John Murray", 1859, "AVAILABLE"}
    };

    private final Object[][] technologyBooks = {
        {"TECH001", "Clean Code", "Prentice Hall", 2008, "AVAILABLE"},
        {"TECH002", "The Pragmatic Programmer", "Addison-Wesley", 1999, "AVAILABLE"},
        {"TECH003", "Code Complete", "Microsoft Press", 2004, "AVAILABLE"},
        {"TECH004", "Introduction to Algorithms", "MIT Press", 2009, "AVAILABLE"},
        {"TECH005", "Design Patterns", "Addison-Wesley", 1994, "AVAILABLE"}
    };

    private final Object[][] lifeBooks = {
        {"LIFE001", "The Power of Now", "New World Library", 1997, "AVAILABLE"},
        {"LIFE002", "Man’s Search for Meaning", "Beacon Press", 1946, "AVAILABLE"},
        {"LIFE003", "The Alchemist", "HarperCollins", 1988, "AVAILABLE"},
        {"LIFE004", "Ikigai", "Penguin Books", 2016, "AVAILABLE"},
        {"LIFE005", "The Art of Happiness", "Riverhead Books", 1998, "AVAILABLE"}
    };

    private final Object[][] moneyBooks = {
        {"MONEY001", "Rich Dad Poor Dad", "Warner Books", 1997, "AVAILABLE"},
        {"MONEY002", "The Millionaire Next Door", "Longstreet Press", 1996, "AVAILABLE"},
        {"MONEY003", "The Intelligent Investor", "Harper Business", 1949, "AVAILABLE"},
        {"MONEY004", "Think and Grow Rich", "The Ralston Society", 1937, "AVAILABLE"},
        {"MONEY005", "Your Money or Your Life", "Penguin Books", 1992, "AVAILABLE"}
    };

    public void setTable(JTable science, JTable technology, JTable life, JTable money) {
        this.scienceTable = science;
        this.technologyTable = technology;
        this.lifeTable = life;
        this.moneyTable = money;
    }

    public void loadAllBooks() {
        loadTable(scienceTable, scienceBooks);
        loadTable(technologyTable, technologyBooks);
        loadTable(lifeTable, lifeBooks);
        loadTable(moneyTable, moneyBooks);
    }

    private void loadTable(JTable table, Object[][] data) {
        if (table != null) {
            DefaultTableModel model = new DefaultTableModel(headers, 0);
            for (Object[] row : data) {
                model.addRow(row);
            }
            table.setModel(model);
        }
    }
     public void deleteBook(int rowID) {
        JTable[] tables = {scienceTable, technologyTable, lifeTable, moneyTable};

        for (JTable table : tables) {
            if (table != null && table.getSelectedRow() != -1) {
                DefaultTableModel model = (DefaultTableModel) table.getModel();

                if (rowID >= 0 && rowID < model.getRowCount()) {
                    model.removeRow(rowID);
                    System.out.println("Deleted row: " + rowID);
                } else {
                    System.out.println("Invalid row index: " + rowID);
                }
                return; 
            }
        }
      
     }
     public void updateNewBook(JTable table, int rowID, String book, String bookName, String pub, String pubYear, String status) {
        if (table == null) {
        JOptionPane.showMessageDialog(null, "Table not found!");
        return;
    }
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        if (rowID >= 0 && rowID < model.getRowCount()) {
                 model.setValueAt(book, rowID, 0);
                 model.setValueAt(bookName, rowID, 1);
                 model.setValueAt(pub, rowID, 2);
                 model.setValueAt(pubYear, rowID, 3);
                 model.setValueAt(status, rowID, 4);
        JOptionPane.showMessageDialog(table, "Book updated successfully!");
    } else {
        JOptionPane.showMessageDialog(table, "Invalid row selected!");
    }
}

    
}
