
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class StudentData {
 
    JTable newStudent;

    String[] headers = {"Student ID", "Name", "Section", "Course"};
    Object[][] students = {
        {"21010", "Victoria Kingsley", "003", "BSCE"},
        {"21011", "Luna Sarton", "001", "BSPSYCH"},
        {"21012", "Corrine Stanford", "002", "BSPSYCH"},
        {"21013", "Shia Sheridan", "001", "BSBA"},
        {"21014", "Cain Apollo", "002", "BSBA"},
        {"21015", "Gin Grey", "001", "BSCE"},
        {"21016", "Ethan Huges", "001", "BSIT"},
        {"21017", "Priam Grey", "002", "BSBA"},
        {"21018", "Lucas Tyler", "001", "BSBA"},
        {"21019", "Luke Tyler", "003", "BSIT"}
    };

    DefaultTableModel model = new DefaultTableModel(headers, 0);

    public void setTable(JTable studentTable) {
        this.newStudent = studentTable;
    }

    public void getnewStudent() {
        model.setRowCount(0);
        for (Object[] s : students) {
            model.addRow(s);
        }
        newStudent.setModel(model);
    }
    public void deleteStudent(int rowID) {
    if (model != null && rowID >= 0 && rowID < model.getRowCount()) {
        model.removeRow(rowID);  // removes the row from the JTable
        System.out.println("Deleted row: " + rowID);
    } else {
        System.out.println("Invalid row index: " + rowID);
    }
}
}

    
