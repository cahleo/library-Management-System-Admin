import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class IssueBookData {
 
    JTable issueTable;

    String[] headers = {"BOOK ID", "STUDENT ID", "ISSUE DATE", "DUE DATE", "STATUS"};
    Object[][] issue = {
        {"SCI003", "21011", "2025-10-16", "2025-10-23", "BORROWED"},
        {"TECH002", "21016", "2025-10-10", "2025-10-17", "BORROWED"},
        {"TECH003", "21012", "2025-10-16", "2025-10-23", "BORROWED"},
        {"LIFE001", "21015", "2025-10-22", "2025-10-29", "BORROWED"},
        {"MONEY001", "21014", "2025-10-21", "2025-10-27", "BORROWED"},
        {"MONEY004", "21013", "2025-10-6", "2025-10-13", "BORROWED"},
        {"SCI004", "21019", "2025-10-27", "2025-11-1", "BORROWED"},
        {"LIFE004", "21017", "2025-10-30", "2025-10-7", "BORROWED"},
        {"MONEY002", "21018", "2025-10-28", "2025-10-5", "BORROWED"},
        {"MONEY001", "21010", "2025-10-30", "2025-10-7", "BORROWED"}
    };

    DefaultTableModel model = new DefaultTableModel(headers, 0);

    public void setTable(JTable issueTable) {
        this.issueTable = issueTable;
    }

    public void getissueBook() {
        model.setRowCount(0); 
        for (Object[] is : issue) {
            model.addRow(is);
        }
        issueTable.setModel(model); 
    }
     public void deleteStudent(int rowID) {
    if (model != null && rowID >= 0 && rowID < model.getRowCount()) {
        model.removeRow(rowID);  // removes the row from the JTable
        System.out.println("Deleted row: " + rowID);
    } else {
        System.out.println("Invalid row index: " + rowID); }
    }
     
    public void updateIssue(int rowID, String book, String bookName, String status){
        model.setValueAt(book, rowID, 0);
        model.setValueAt(bookName, rowID, 1);
        model.setValueAt(status, rowID, 4);
        JOptionPane.showMessageDialog(issueTable, "Issue Update Succesfully");
      
    }
}

    
